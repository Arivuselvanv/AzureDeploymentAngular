import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders }    from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {

 baseURL :any;

constructor(private http: HttpClient) { }

 
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }  


  getData(){
     
    return this.http.get('https://learning20200718210841.azurewebsites.net/api/Employee');  
  }

  postData(formData){
    return this.http.post('https://learning20200718210841.azurewebsites.net/api/Employee',formData);
  }

  putData(id,formData){
    return this.http.put('https://learning20200718210841.azurewebsites.net/api/Employee/'+id,formData);
  }
  deleteData(id){
    return this.http.delete('https://learning20200718210841.azurewebsites.net/api/api/Employee/'+id);
  }
  
}
